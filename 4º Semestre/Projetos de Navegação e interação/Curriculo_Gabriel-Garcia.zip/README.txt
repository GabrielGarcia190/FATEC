Fiz o trabalho usando tailwind e React JS
para visualizar é só ter node.js instalado 
e executar o comando "npm run dev".
