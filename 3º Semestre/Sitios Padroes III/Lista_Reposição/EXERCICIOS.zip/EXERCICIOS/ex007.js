sortearNum();

function sortearNum(){
   let numSortado = Math.floor(Math.random() * (75 + 1));
    console.log(numSortado);
}